/**
 * mathUtils.js
 * ------------
 * All math logic for the calculator app lives here as pure functions,
 * deliberately separated from any React/React Native UI code so it can
 * be unit tested in plain Node and reused across screens.
 *
 * Sections:
 *   1. Expression parser/evaluator (tokenizer -> recursive descent parser -> eval)
 *   2. Trigonometric & hyperbolic helpers (DEG/RAD aware)
 *   3. Combinatorics (factorial, nPr, nCr)
 *   4. Matrix operations (NxN: add, subtract, multiply, determinant, inverse, transpose)
 *   5. Statistics (mean, median, mode, variance, stddev, range, min, max)
 */

// ============================================================
// 1. EXPRESSION PARSER / EVALUATOR
// ============================================================
//
// Grammar (precedence low -> high), standard recursive descent:
//
//   expression := term (('+' | '-') term)*
//   term       := unary (('*' | '/' | '%') unary)*
//   unary      := ('-' | '+')? power
//   power      := postfix ('^' unary)?              // right-assoc, binds tighter than unary minus on the RHS
//   postfix    := primary ('!')*
//   primary    := NUMBER
//               | CONST                              // pi, e
//               | FUNC '(' expression (',' expression)* ')'
//               | '(' expression ')'
//               | primary primary                    // implicit multiplication, e.g. "2(3+4)" or "2pi"
//
// Implicit multiplication is handled in `term()` by checking, after consuming
// a unary, whether the next token can start a new primary (number, '(', func,
// const) with no explicit operator between -- if so, we insert a '*'.

const FUNCTIONS = new Set([
  'sin', 'cos', 'tan', 'asin', 'acos', 'atan',
  'sinh', 'cosh', 'tanh',
  'log', 'ln', 'sqrt', 'abs',
]);

const CONSTANTS = {
  pi: Math.PI,
  e: Math.E,
};

class TokenizerError extends Error {}
class ParseError extends Error {}

/**
 * Turn an expression string into a flat array of tokens.
 * Token shapes: { type: 'num', value: number }
 *               { type: 'ident', value: string }   // could be func name or const name
 *               { type: 'op', value: '+'|'-'|'*'|'/'|'%'|'^'|'!' }
 *               { type: 'lparen' } / { type: 'rparen' } / { type: 'comma' }
 */
function tokenize(input) {
  const tokens = [];
  let i = 0;
  const s = input.replace(/\s+/g, '');

  while (i < s.length) {
    const c = s[i];

    if (/[0-9.]/.test(c)) {
      let j = i;
      let seenDot = false;
      while (j < s.length && /[0-9.]/.test(s[j])) {
        if (s[j] === '.') {
          if (seenDot) throw new TokenizerError(`Unexpected second decimal point near "${s.slice(i, j + 1)}"`);
          seenDot = true;
        }
        j++;
      }
      const raw = s.slice(i, j);
      if (raw === '.' || raw === '') throw new TokenizerError('Invalid number literal');
      tokens.push({ type: 'num', value: parseFloat(raw) });
      i = j;
      continue;
    }

    if (/[a-zA-Z]/.test(c)) {
      let j = i;
      while (j < s.length && /[a-zA-Z]/.test(s[j])) j++;
      tokens.push({ type: 'ident', value: s.slice(i, j) });
      i = j;
      continue;
    }

    if ('+-*/%^!'.includes(c)) {
      tokens.push({ type: 'op', value: c });
      i++;
      continue;
    }

    if (c === '(') { tokens.push({ type: 'lparen' }); i++; continue; }
    if (c === ')') { tokens.push({ type: 'rparen' }); i++; continue; }
    if (c === ',') { tokens.push({ type: 'comma' }); i++; continue; }

    // Common "pretty" calculator glyphs, normalized to ASCII equivalents.
    if (c === '\u00d7') { tokens.push({ type: 'op', value: '*' }); i++; continue; }
    if (c === '\u00f7') { tokens.push({ type: 'op', value: '/' }); i++; continue; }
    if (c === '\u2212') { tokens.push({ type: 'op', value: '-' }); i++; continue; }
    if (c === '\u03c0') { tokens.push({ type: 'ident', value: 'pi' }); i++; continue; }

    throw new TokenizerError(`Unexpected character "${c}" in expression`);
  }

  return tokens;
}

/**
 * Build an evaluator from tokens. `angleMode` is 'deg' or 'rad' and controls
 * how sin/cos/tan/asin/acos/atan interpret and produce angles.
 */
function createParser(tokens, angleMode) {
  let pos = 0;

  function peek() { return tokens[pos]; }
  function atEnd() { return pos >= tokens.length; }
  function advance() { return tokens[pos++]; }

  function expect(type) {
    const tok = peek();
    if (!tok || tok.type !== type) {
      throw new ParseError(`Expected ${type} but got ${tok ? tok.type : 'end of input'}`);
    }
    return advance();
  }

  // Can the current token start a new primary expression with no operator?
  // Used to detect implicit multiplication like "2pi" or "2(3+4)" or "3sin(90)".
  function startsPrimary() {
    const tok = peek();
    if (!tok) return false;
    if (tok.type === 'num') return true;
    if (tok.type === 'lparen') return true;
    if (tok.type === 'ident') return true; // function name or constant
    return false;
  }

  function toRadians(x) { return angleMode === 'deg' ? (x * Math.PI) / 180 : x; }
  function toDegrees(x) { return angleMode === 'deg' ? (x * 180) / Math.PI : x; }

  function applyFunction(name, args) {
    const x = args[0];
    switch (name) {
      case 'sin': return Math.sin(toRadians(x));
      case 'cos': return Math.cos(toRadians(x));
      case 'tan': return Math.tan(toRadians(x));
      case 'asin': return toDegrees(Math.asin(x));
      case 'acos': return toDegrees(Math.acos(x));
      case 'atan': return toDegrees(Math.atan(x));
      case 'sinh': return Math.sinh(x);
      case 'cosh': return Math.cosh(x);
      case 'tanh': return Math.tanh(x);
      case 'log': return Math.log10(x);
      case 'ln': return Math.log(x);
      case 'sqrt': return Math.sqrt(x);
      case 'abs': return Math.abs(x);
      default:
        throw new ParseError(`Unknown function "${name}"`);
    }
  }

  function factorial(n) {
    if (n < 0) throw new ParseError('Factorial of a negative number is undefined');
    if (Math.floor(n) !== n) throw new ParseError('Factorial requires a whole number');
    if (n > 170) return Infinity;
    let result = 1;
    for (let k = 2; k <= n; k++) result *= k;
    return result;
  }

  // primary := NUMBER | CONST | FUNC '(' args ')' | '(' expression ')'
  function primary() {
    const tok = peek();
    if (!tok) throw new ParseError('Unexpected end of expression');

    if (tok.type === 'num') {
      advance();
      return tok.value;
    }

    if (tok.type === 'lparen') {
      advance();
      const value = expression();
      expect('rparen');
      return value;
    }

    if (tok.type === 'ident') {
      const name = tok.value.toLowerCase();
      advance();

      if (FUNCTIONS.has(name)) {
        expect('lparen');
        const args = [expression()];
        while (peek() && peek().type === 'comma') {
          advance();
          args.push(expression());
        }
        expect('rparen');
        return applyFunction(name, args);
      }

      if (name in CONSTANTS) {
        return CONSTANTS[name];
      }

      throw new ParseError(`Unknown identifier "${tok.value}"`);
    }

    throw new ParseError(`Unexpected token: ${JSON.stringify(tok)}`);
  }

  // postfix := primary ('!')*
  function postfix() {
    let value = primary();
    while (peek() && peek().type === 'op' && peek().value === '!') {
      advance();
      value = factorial(value);
    }
    return value;
  }

  // power := postfix ('^' unary)?   (right-associative)
  function power() {
    const base = postfix();
    if (peek() && peek().type === 'op' && peek().value === '^') {
      advance();
      const exponent = unary(); // right-assoc + lets "-2^2" parse as -(2^2) via unary handling below
      return Math.pow(base, exponent);
    }
    return base;
  }

  // unary := ('-' | '+')? power
  function unary() {
    if (peek() && peek().type === 'op' && (peek().value === '-' || peek().value === '+')) {
      const op = advance().value;
      const value = unary();
      return op === '-' ? -value : value;
    }
    return power();
  }

  // term := unary (('*' | '/' | '%') unary | implicit-multiplication)*
  function term() {
    let value = unary();
    for (;;) {
      const tok = peek();
      if (tok && tok.type === 'op' && (tok.value === '*' || tok.value === '/' || tok.value === '%')) {
        advance();
        const rhs = unary();
        if (tok.value === '*') value *= rhs;
        else if (tok.value === '/') {
          if (rhs === 0) throw new ParseError('Division by zero');
          value /= rhs;
        } else value %= rhs;
        continue;
      }
      // implicit multiplication: "2pi", "3(4+5)", "2sin(30)"
      if (startsPrimary()) {
        const rhs = unary();
        value *= rhs;
        continue;
      }
      break;
    }
    return value;
  }

  // expression := term (('+' | '-') term)*
  function expression() {
    let value = term();
    for (;;) {
      const tok = peek();
      if (tok && tok.type === 'op' && (tok.value === '+' || tok.value === '-')) {
        advance();
        const rhs = term();
        value = tok.value === '+' ? value + rhs : value - rhs;
        continue;
      }
      break;
    }
    return value;
  }

  return {
    run() {
      if (tokens.length === 0) throw new ParseError('Empty expression');
      const result = expression();
      if (!atEnd()) {
        throw new ParseError(`Unexpected trailing token: ${JSON.stringify(peek())}`);
      }
      return result;
    },
  };
}

/**
 * Evaluate a calculator expression string.
 * @param {string} input - e.g. "sin(30)+2^3", "2pi", "5!"
 * @param {'deg'|'rad'} angleMode - how trig functions interpret/produce angles
 * @returns {number}
 * @throws {Error} on malformed input, with a human-readable message
 */
function evaluateExpression(input, angleMode = 'deg') {
  if (typeof input !== 'string' || input.trim() === '') {
    throw new Error('Expression is empty');
  }
  // Auto-balance unclosed parentheses, mirroring forgiving calculator UX.
  let normalized = input;
  const opens = (normalized.match(/\(/g) || []).length;
  const closes = (normalized.match(/\)/g) || []).length;
  if (closes < opens) normalized += ')'.repeat(opens - closes);

  const tokens = tokenize(normalized);
  const parser = createParser(tokens, angleMode);
  const result = parser.run();

  if (typeof result !== 'number' || Number.isNaN(result)) {
    throw new Error('Result is not a number (check your inputs)');
  }
  if (!Number.isFinite(result)) {
    throw new Error('Result is infinite (division by zero or overflow)');
  }
  return result;
}

// ============================================================
// 2. STANDALONE TRIG / HYPERBOLIC HELPERS
// ============================================================
// Exposed individually too, in case a screen wants direct access
// without going through the expression parser.

function toRadians(degrees) {
  return (degrees * Math.PI) / 180;
}

function toDegrees(radians) {
  return (radians * 180) / Math.PI;
}

const trig = {
  sin: (x, mode = 'deg') => Math.sin(mode === 'deg' ? toRadians(x) : x),
  cos: (x, mode = 'deg') => Math.cos(mode === 'deg' ? toRadians(x) : x),
  tan: (x, mode = 'deg') => Math.tan(mode === 'deg' ? toRadians(x) : x),
  asin: (x, mode = 'deg') => (mode === 'deg' ? toDegrees(Math.asin(x)) : Math.asin(x)),
  acos: (x, mode = 'deg') => (mode === 'deg' ? toDegrees(Math.acos(x)) : Math.acos(x)),
  atan: (x, mode = 'deg') => (mode === 'deg' ? toDegrees(Math.atan(x)) : Math.atan(x)),
};

const hyperbolic = {
  sinh: (x) => Math.sinh(x),
  cosh: (x) => Math.cosh(x),
  tanh: (x) => Math.tanh(x),
};

// ============================================================
// 3. COMBINATORICS
// ============================================================

/**
 * n! (factorial). Accepts non-negative integers only.
 */
function factorial(n) {
  if (typeof n !== 'number' || Number.isNaN(n)) throw new Error('factorial: input must be a number');
  if (n < 0) throw new Error('factorial: input must be non-negative');
  if (Math.floor(n) !== n) throw new Error('factorial: input must be an integer');
  if (n > 170) return Infinity; // beyond double precision range
  let result = 1;
  for (let k = 2; k <= n; k++) result *= k;
  return result;
}

/**
 * nPr = n! / (n - r)!  -- permutations of r items from n.
 * Computed iteratively (not via factorial(n)/factorial(n-r)) to avoid
 * overflow to Infinity for large n when the ratio itself is representable.
 */
function nPr(n, r) {
  validateCombinatoricsInputs(n, r);
  if (r > n) throw new Error('nPr: r cannot be greater than n');
  let result = 1;
  for (let k = 0; k < r; k++) result *= (n - k);
  return result;
}

/**
 * nCr = n! / (r! * (n - r)!) -- combinations of r items from n.
 * Computed iteratively using the multiplicative formula to keep
 * intermediate values small and avoid floating point blowups.
 */
function nCr(n, r) {
  validateCombinatoricsInputs(n, r);
  if (r > n) throw new Error('nCr: r cannot be greater than n');
  // Use the smaller of r and n-r to minimize iterations/intermediate size.
  const k = Math.min(r, n - r);
  let result = 1;
  for (let i = 0; i < k; i++) {
    result = (result * (n - i)) / (i + 1);
  }
  return Math.round(result);
}

function validateCombinatoricsInputs(n, r) {
  if (typeof n !== 'number' || typeof r !== 'number' || Number.isNaN(n) || Number.isNaN(r)) {
    throw new Error('nPr/nCr: n and r must be numbers');
  }
  if (n < 0 || r < 0) throw new Error('nPr/nCr: n and r must be non-negative');
  if (Math.floor(n) !== n || Math.floor(r) !== r) throw new Error('nPr/nCr: n and r must be integers');
}

// ============================================================
// 4. MATRIX OPERATIONS (general NxN, used for 2x2/3x3/4x4 in the UI)
// ============================================================
//
// Matrices are represented as arrays of arrays of numbers:
//   [[1, 2], [3, 4]]  =>  | 1 2 |
//                         | 3 4 |

function getDimensions(matrix) {
  if (!Array.isArray(matrix) || matrix.length === 0 || !Array.isArray(matrix[0])) {
    throw new Error('Matrix must be a non-empty array of arrays');
  }
  const rows = matrix.length;
  const cols = matrix[0].length;
  for (const row of matrix) {
    if (!Array.isArray(row) || row.length !== cols) {
      throw new Error('All matrix rows must have the same length');
    }
    for (const val of row) {
      if (typeof val !== 'number' || Number.isNaN(val)) {
        throw new Error('Matrix entries must all be numbers');
      }
    }
  }
  return { rows, cols };
}

function matrixAdd(a, b) {
  const da = getDimensions(a);
  const db = getDimensions(b);
  if (da.rows !== db.rows || da.cols !== db.cols) {
    throw new Error('matrixAdd: matrices must have the same dimensions');
  }
  return a.map((row, i) => row.map((val, j) => val + b[i][j]));
}

function matrixSubtract(a, b) {
  const da = getDimensions(a);
  const db = getDimensions(b);
  if (da.rows !== db.rows || da.cols !== db.cols) {
    throw new Error('matrixSubtract: matrices must have the same dimensions');
  }
  return a.map((row, i) => row.map((val, j) => val - b[i][j]));
}

function matrixMultiply(a, b) {
  const da = getDimensions(a);
  const db = getDimensions(b);
  if (da.cols !== db.rows) {
    throw new Error(
      `matrixMultiply: incompatible dimensions (${da.rows}x${da.cols}) x (${db.rows}x${db.cols})`
    );
  }
  const result = [];
  for (let i = 0; i < da.rows; i++) {
    const row = [];
    for (let j = 0; j < db.cols; j++) {
      let sum = 0;
      for (let k = 0; k < da.cols; k++) sum += a[i][k] * b[k][j];
      row.push(sum);
    }
    result.push(row);
  }
  return result;
}

function matrixTranspose(a) {
  const { rows, cols } = getDimensions(a);
  const result = [];
  for (let j = 0; j < cols; j++) {
    const row = [];
    for (let i = 0; i < rows; i++) row.push(a[i][j]);
    result.push(row);
  }
  return result;
}

/**
 * Determinant via cofactor expansion. Fine for the 2x2/3x3/4x4 sizes this
 * app supports (max 24 recursive multiplications at 4x4), though Gaussian
 * elimination (used in matrixInverse below) would scale better for larger N.
 */
function matrixDeterminant(a) {
  const { rows, cols } = getDimensions(a);
  if (rows !== cols) throw new Error('matrixDeterminant: matrix must be square');
  return determinantRecursive(a);
}

function determinantRecursive(a) {
  const n = a.length;
  if (n === 1) return a[0][0];
  if (n === 2) return a[0][0] * a[1][1] - a[0][1] * a[1][0];

  let det = 0;
  for (let col = 0; col < n; col++) {
    const minor = a.slice(1).map((row) => row.filter((_, j) => j !== col));
    const sign = col % 2 === 0 ? 1 : -1;
    det += sign * a[0][col] * determinantRecursive(minor);
  }
  return det;
}

/**
 * Matrix inverse via Gauss-Jordan elimination with partial pivoting.
 * Works for any square NxN (used here for 2x2, 3x3, 4x4). Throws if the
 * matrix is singular (determinant ~ 0).
 */
function matrixInverse(a) {
  const { rows, cols } = getDimensions(a);
  if (rows !== cols) throw new Error('matrixInverse: matrix must be square');
  const n = rows;
  const EPSILON = 1e-10;

  // Build augmented matrix [A | I]
  const aug = a.map((row, i) => [
    ...row,
    ...Array.from({ length: n }, (_, j) => (i === j ? 1 : 0)),
  ]);

  for (let col = 0; col < n; col++) {
    // Partial pivot: find the row with the largest absolute value in this column.
    let pivotRow = col;
    let maxVal = Math.abs(aug[col][col]);
    for (let r = col + 1; r < n; r++) {
      if (Math.abs(aug[r][col]) > maxVal) {
        maxVal = Math.abs(aug[r][col]);
        pivotRow = r;
      }
    }
    if (maxVal < EPSILON) {
      throw new Error('matrixInverse: matrix is singular (determinant is zero), cannot invert');
    }
    if (pivotRow !== col) {
      [aug[col], aug[pivotRow]] = [aug[pivotRow], aug[col]];
    }

    // Normalize pivot row so the pivot element becomes 1.
    const pivotVal = aug[col][col];
    for (let j = 0; j < 2 * n; j++) aug[col][j] /= pivotVal;

    // Eliminate this column from all other rows.
    for (let r = 0; r < n; r++) {
      if (r === col) continue;
      const factor = aug[r][col];
      if (factor === 0) continue;
      for (let j = 0; j < 2 * n; j++) aug[r][j] -= factor * aug[col][j];
    }
  }

  // Right half of the augmented matrix is now the inverse.
  return aug.map((row) => row.slice(n).map((v) => (Math.abs(v) < EPSILON ? 0 : v)));
}

// ============================================================
// 5. STATISTICS
// ============================================================

function validateNumericArray(data, fnName) {
  if (!Array.isArray(data) || data.length === 0) {
    throw new Error(`${fnName}: input must be a non-empty array of numbers`);
  }
  for (const v of data) {
    if (typeof v !== 'number' || Number.isNaN(v)) {
      throw new Error(`${fnName}: all entries must be numbers`);
    }
  }
}

function mean(data) {
  validateNumericArray(data, 'mean');
  return data.reduce((sum, v) => sum + v, 0) / data.length;
}

function median(data) {
  validateNumericArray(data, 'median');
  const sorted = [...data].sort((a, b) => a - b);
  const mid = Math.floor(sorted.length / 2);
  if (sorted.length % 2 === 0) {
    return (sorted[mid - 1] + sorted[mid]) / 2;
  }
  return sorted[mid];
}

/**
 * Returns an array of modes (can be more than one if there's a tie).
 * If every value appears exactly once, every value is returned (matches
 * the conventional "no unique mode" case as "all values tied at freq 1").
 */
function mode(data) {
  validateNumericArray(data, 'mode');
  const counts = new Map();
  for (const v of data) counts.set(v, (counts.get(v) || 0) + 1);
  const maxCount = Math.max(...counts.values());
  return [...counts.entries()].filter(([, c]) => c === maxCount).map(([v]) => v);
}

/**
 * Sample variance (divides by n - 1) by default, matching common stats
 * course conventions; pass { population: true } for population variance (divides by n).
 */
function variance(data, { population = false } = {}) {
  validateNumericArray(data, 'variance');
  if (!population && data.length < 2) {
    throw new Error('variance: sample variance requires at least 2 data points');
  }
  const m = mean(data);
  const sumSquaredDiffs = data.reduce((sum, v) => sum + (v - m) ** 2, 0);
  const divisor = population ? data.length : data.length - 1;
  return sumSquaredDiffs / divisor;
}

function standardDeviation(data, options = {}) {
  return Math.sqrt(variance(data, options));
}

function range(data) {
  validateNumericArray(data, 'range');
  return Math.max(...data) - Math.min(...data);
}

function min(data) {
  validateNumericArray(data, 'min');
  return Math.min(...data);
}

function max(data) {
  validateNumericArray(data, 'max');
  return Math.max(...data);
}

/**
 * Convenience bundle: compute every stat at once for a summary view.
 */
function summarizeStatistics(data) {
  validateNumericArray(data, 'summarizeStatistics');
  return {
    count: data.length,
    mean: mean(data),
    median: median(data),
    mode: mode(data),
    variance: data.length >= 2 ? variance(data) : null,
    standardDeviation: data.length >= 2 ? standardDeviation(data) : null,
    range: range(data),
    min: min(data),
    max: max(data),
  };
}

// ============================================================
// EXPORTS
// ============================================================

module.exports = {
  // expression engine
  evaluateExpression,
  tokenize,
  // trig / hyperbolic
  toRadians,
  toDegrees,
  trig,
  hyperbolic,
  // combinatorics
  factorial,
  nPr,
  nCr,
  // matrices
  matrixAdd,
  matrixSubtract,
  matrixMultiply,
  matrixTranspose,
  matrixDeterminant,
  matrixInverse,
  getDimensions,
  // statistics
  mean,
  median,
  mode,
  variance,
  standardDeviation,
  range,
  min,
  max,
  summarizeStatistics,
};
