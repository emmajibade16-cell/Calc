/**
 * theme.js
 * --------
 * Shared color tokens, spacing, and typography for the dark UI used
 * consistently across all four screens (Calculator, Matrix, Combinatorics,
 * Statistics).
 */

export const colors = {
  bg: '#0d0e12',
  panel: '#16181d',
  panelLight: '#1e2128',
  display: '#0b0c0f',
  border: 'rgba(255,255,255,0.07)',

  textPrimary: '#e8e6e1',
  textSecondary: '#9a9da6',
  textMuted: '#5f626c',

  key: '#21242b',
  keyHover: '#2a2e37',
  keyFn: '#262b35',

  accentOrange: '#ff7a30',
  accentOrangeDim: '#3a2818',
  accentBlue: '#5b8af0',
  accentBlueDim: '#1c2740',
  accentGreen: '#4cd07a',
  accentGreenDim: '#163322',

  danger: '#ff5c5c',
  dangerDim: '#3a1c1c',
};

export const spacing = {
  xs: 4,
  sm: 8,
  md: 12,
  lg: 16,
  xl: 24,
};

export const radius = {
  sm: 8,
  md: 14,
  lg: 20,
  pill: 999,
};

export const typography = {
  mono: 'monospace',
  display: {
    fontSize: 38,
    fontWeight: '600',
  },
  label: {
    fontSize: 12,
    fontWeight: '600',
    letterSpacing: 0.5,
  },
  body: {
    fontSize: 15,
    fontWeight: '400',
  },
};

export default { colors, spacing, radius, typography };
