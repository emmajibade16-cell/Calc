/**
 * CombinatoricsScreen.js
 * ----------------------
 * Two numeric inputs (n, r) feed factorial(n), nPr(n,r), and nCr(n,r).
 * Each result updates live as the user types, with per-card error states
 * (e.g. "r cannot be greater than n") instead of one global error banner,
 * since the three calculations can independently succeed or fail.
 */

import React, { useState, useMemo } from 'react';
import { View, Text, TextInput, StyleSheet, SafeAreaView, ScrollView } from 'react-native';
import { factorial, nPr, nCr } from '../utils/mathUtils';
import { colors, spacing, radius } from '../theme';

function parseIntOrNull(text) {
  if (text.trim() === '') return null;
  const v = Number(text);
  if (Number.isNaN(v)) return null;
  return v;
}

function safeCompute(fn) {
  try {
    return { value: fn(), error: null };
  } catch (e) {
    return { value: null, error: e.message };
  }
}

export default function CombinatoricsScreen() {
  const [nText, setNText] = useState('5');
  const [rText, setRText] = useState('2');

  const n = parseIntOrNull(nText);
  const r = parseIntOrNull(rText);

  const factorialResult = useMemo(() => {
    if (n === null) return { value: null, error: 'Enter n' };
    return safeCompute(() => factorial(n));
  }, [n]);

  const nPrResult = useMemo(() => {
    if (n === null || r === null) return { value: null, error: 'Enter n and r' };
    return safeCompute(() => nPr(n, r));
  }, [n, r]);

  const nCrResult = useMemo(() => {
    if (n === null || r === null) return { value: null, error: 'Enter n and r' };
    return safeCompute(() => nCr(n, r));
  }, [n, r]);

  return (
    <SafeAreaView style={styles.safeArea}>
      <ScrollView contentContainerStyle={styles.container}>
        <Text style={styles.heading}>Permutations & combinations</Text>
        <Text style={styles.subheading}>
          Enter whole numbers for n (total items) and r (items chosen).
        </Text>

        <View style={styles.inputRow}>
          <View style={styles.inputGroup}>
            <Text style={styles.inputLabel}>n</Text>
            <TextInput
              style={styles.input}
              value={nText}
              onChangeText={setNText}
              keyboardType="numeric"
              placeholder="0"
              placeholderTextColor={colors.textMuted}
            />
          </View>
          <View style={styles.inputGroup}>
            <Text style={styles.inputLabel}>r</Text>
            <TextInput
              style={styles.input}
              value={rText}
              onChangeText={setRText}
              keyboardType="numeric"
              placeholder="0"
              placeholderTextColor={colors.textMuted}
            />
          </View>
        </View>

        <ResultCard
          title="Factorial"
          formula="n!"
          result={factorialResult}
        />
        <ResultCard
          title="Permutations"
          formula="nPr = n! / (n − r)!"
          result={nPrResult}
        />
        <ResultCard
          title="Combinations"
          formula="nCr = n! / (r!(n − r)!)"
          result={nCrResult}
        />
      </ScrollView>
    </SafeAreaView>
  );
}

function formatResult(value) {
  if (value === Infinity) return '∞ (too large)';
  if (typeof value === 'number') return value.toLocaleString();
  return String(value);
}

function ResultCard({ title, formula, result }) {
  return (
    <View style={styles.card}>
      <View style={styles.cardHeader}>
        <Text style={styles.cardTitle}>{title}</Text>
        <Text style={styles.cardFormula}>{formula}</Text>
      </View>
      {result.error ? (
        <Text style={styles.cardError}>{result.error}</Text>
      ) : (
        <Text style={styles.cardValue} numberOfLines={1}>{formatResult(result.value)}</Text>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  safeArea: { flex: 1, backgroundColor: colors.bg },
  container: { padding: spacing.lg, paddingBottom: spacing.xl * 2 },

  heading: { color: colors.textPrimary, fontSize: 20, fontWeight: '700' },
  subheading: { color: colors.textSecondary, fontSize: 13, marginTop: 4, marginBottom: spacing.lg },

  inputRow: { flexDirection: 'row', gap: spacing.md, marginBottom: spacing.lg },
  inputGroup: { flex: 1 },
  inputLabel: { color: colors.textSecondary, fontSize: 13, fontWeight: '600', marginBottom: 6 },
  input: {
    backgroundColor: colors.display,
    borderRadius: radius.md,
    color: colors.textPrimary,
    fontFamily: 'monospace',
    fontSize: 20,
    paddingVertical: 12,
    paddingHorizontal: spacing.md,
  },

  card: {
    backgroundColor: colors.panel,
    borderRadius: radius.md,
    padding: spacing.lg,
    marginBottom: spacing.md,
  },
  cardHeader: { marginBottom: spacing.sm },
  cardTitle: { color: colors.textPrimary, fontSize: 15, fontWeight: '700' },
  cardFormula: { color: colors.textMuted, fontSize: 12, fontFamily: 'monospace', marginTop: 2 },
  cardValue: { color: colors.accentGreen, fontSize: 26, fontFamily: 'monospace', fontWeight: '600' },
  cardError: { color: colors.danger, fontSize: 13 },
});
