/**
 * StatisticsScreen.js
 * -------------------
 * Free-text dataset entry (comma or space separated numbers), parsed into
 * a number array and run through utils/mathUtils.summarizeStatistics plus
 * the individual mean/median/mode/variance/stddev/range/min/max functions.
 */

import React, { useState, useMemo } from 'react';
import { View, Text, TextInput, StyleSheet, SafeAreaView, ScrollView } from 'react-native';
import { summarizeStatistics } from '../utils/mathUtils';
import { colors, spacing, radius } from '../theme';

function parseDataset(text) {
  if (!text.trim()) return { data: [], error: null };
  const parts = text.split(/[,\s]+/).filter((p) => p.length > 0);
  const data = [];
  for (const part of parts) {
    const v = Number(part);
    if (Number.isNaN(v)) {
      return { data: [], error: `"${part}" is not a valid number` };
    }
    data.push(v);
  }
  return { data, error: null };
}

export default function StatisticsScreen() {
  const [text, setText] = useState('4, 8, 6, 5, 3, 2, 8, 9, 2, 5');

  const { data, error: parseError } = useMemo(() => parseDataset(text), [text]);

  const summary = useMemo(() => {
    if (parseError || data.length === 0) return null;
    try {
      return summarizeStatistics(data);
    } catch (e) {
      return null;
    }
  }, [data, parseError]);

  const computeError = !parseError && data.length === 0 ? 'Enter at least one number' : null;

  return (
    <SafeAreaView style={styles.safeArea}>
      <ScrollView contentContainerStyle={styles.container}>
        <Text style={styles.heading}>Statistics</Text>
        <Text style={styles.subheading}>
          Enter a dataset separated by commas or spaces.
        </Text>

        <TextInput
          style={styles.input}
          value={text}
          onChangeText={setText}
          placeholder="e.g. 4, 8, 6, 5, 3"
          placeholderTextColor={colors.textMuted}
          multiline
        />

        {parseError && <Text style={styles.errorText}>{parseError}</Text>}
        {computeError && <Text style={styles.errorText}>{computeError}</Text>}

        {summary && (
          <>
            <View style={styles.grid}>
              <StatCard label="Count" value={summary.count} />
              <StatCard label="Mean" value={fmt(summary.mean)} />
              <StatCard label="Median" value={fmt(summary.median)} />
              <StatCard label="Mode" value={summary.mode.map(fmt).join(', ')} />
              <StatCard label="Range" value={fmt(summary.range)} />
              <StatCard label="Min" value={fmt(summary.min)} />
              <StatCard label="Max" value={fmt(summary.max)} />
              <StatCard
                label="Variance"
                value={summary.variance !== null ? fmt(summary.variance) : 'n/a (need 2+ values)'}
              />
              <StatCard
                label="Std deviation"
                value={summary.standardDeviation !== null ? fmt(summary.standardDeviation) : 'n/a (need 2+ values)'}
              />
            </View>

            <Text style={styles.note}>
              Variance and standard deviation use the sample formula (divide by n − 1).
            </Text>
          </>
        )}
      </ScrollView>
    </SafeAreaView>
  );
}

function fmt(n) {
  if (typeof n !== 'number') return String(n);
  const rounded = Math.round(n * 1e6) / 1e6;
  return rounded.toLocaleString();
}

function StatCard({ label, value }) {
  return (
    <View style={styles.card}>
      <Text style={styles.cardLabel}>{label}</Text>
      <Text style={styles.cardValue} numberOfLines={1}>{value}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  safeArea: { flex: 1, backgroundColor: colors.bg },
  container: { padding: spacing.lg, paddingBottom: spacing.xl * 2 },

  heading: { color: colors.textPrimary, fontSize: 20, fontWeight: '700' },
  subheading: { color: colors.textSecondary, fontSize: 13, marginTop: 4, marginBottom: spacing.lg },

  input: {
    backgroundColor: colors.display,
    borderRadius: radius.md,
    color: colors.textPrimary,
    fontFamily: 'monospace',
    fontSize: 16,
    padding: spacing.md,
    minHeight: 56,
    marginBottom: spacing.md,
  },
  errorText: { color: colors.danger, fontSize: 13, marginBottom: spacing.md },

  grid: { flexDirection: 'row', flexWrap: 'wrap', gap: spacing.sm, marginTop: spacing.sm },
  card: {
    flexBasis: '47%',
    flexGrow: 1,
    backgroundColor: colors.panel,
    borderRadius: radius.md,
    padding: spacing.md,
  },
  cardLabel: { color: colors.textSecondary, fontSize: 12, fontWeight: '600', marginBottom: 4 },
  cardValue: { color: colors.accentGreen, fontSize: 18, fontFamily: 'monospace', fontWeight: '600' },

  note: { color: colors.textMuted, fontSize: 12, marginTop: spacing.lg, fontStyle: 'italic' },
});
