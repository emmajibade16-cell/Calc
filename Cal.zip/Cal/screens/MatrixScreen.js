/**
 * MatrixScreen.js
 * ---------------
 * Lets the user pick a matrix size (2x2, 3x3, 4x4), type values into two
 * grid inputs (A and B), and run add/subtract/multiply/determinant/
 * inverse/transpose. Binary operations (add/subtract/multiply) use both
 * matrices; unary operations (determinant/inverse/transpose) use matrix A.
 * All math comes from utils/mathUtils.js -- this screen only handles
 * collecting grid input and displaying the result grid.
 */

import React, { useState } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  ScrollView,
  StyleSheet,
  SafeAreaView,
} from 'react-native';
import {
  matrixAdd,
  matrixSubtract,
  matrixMultiply,
  matrixDeterminant,
  matrixInverse,
  matrixTranspose,
} from '../utils/mathUtils';
import { colors, spacing, radius } from '../theme';

const SIZES = [2, 3, 4];
const BINARY_OPS = [
  { key: 'add', label: '+', fn: matrixAdd },
  { key: 'sub', label: '−', fn: matrixSubtract },
  { key: 'mul', label: '×', fn: matrixMultiply },
];
const UNARY_OPS = [
  { key: 'det', label: 'det(A)' },
  { key: 'inv', label: 'A⁻¹' },
  { key: 'trans', label: 'Aᵗ' },
];

function emptyGrid(n) {
  return Array.from({ length: n }, () => Array.from({ length: n }, () => ''));
}

function gridToNumbers(grid) {
  return grid.map((row) => row.map((cell) => {
    const v = parseFloat(cell);
    return Number.isNaN(v) ? 0 : v;
  }));
}

export default function MatrixScreen() {
  const [size, setSize] = useState(2);
  const [gridA, setGridA] = useState(emptyGrid(2));
  const [gridB, setGridB] = useState(emptyGrid(2));
  const [result, setResult] = useState(null); // number[][] | number | null
  const [error, setError] = useState(null);
  const [needsB, setNeedsB] = useState(true);

  function changeSize(n) {
    setSize(n);
    setGridA(emptyGrid(n));
    setGridB(emptyGrid(n));
    setResult(null);
    setError(null);
  }

  function updateCell(which, row, col, value) {
    // Allow free typing, including a leading "-" or in-progress decimals.
    const setGrid = which === 'A' ? setGridA : setGridB;
    setGrid((prev) => {
      const next = prev.map((r) => [...r]);
      next[row][col] = value;
      return next;
    });
  }

  function runBinaryOp(op) {
    setError(null);
    try {
      const a = gridToNumbers(gridA);
      const b = gridToNumbers(gridB);
      const out = op.fn(a, b);
      setResult(out);
    } catch (e) {
      setError(e.message);
      setResult(null);
    }
  }

  function runUnaryOp(key) {
    setError(null);
    try {
      const a = gridToNumbers(gridA);
      if (key === 'det') setResult(matrixDeterminant(a));
      else if (key === 'inv') setResult(matrixInverse(a));
      else if (key === 'trans') setResult(matrixTranspose(a));
    } catch (e) {
      setError(e.message);
      setResult(null);
    }
  }

  const resultIsScalar = typeof result === 'number';

  return (
    <SafeAreaView style={styles.safeArea}>
      <ScrollView contentContainerStyle={styles.container}>
        <Text style={styles.sectionLabel}>Matrix size</Text>
        <View style={styles.sizeRow}>
          {SIZES.map((n) => (
            <TouchableOpacity
              key={n}
              style={[styles.sizeBtn, size === n && styles.sizeBtnActive]}
              onPress={() => changeSize(n)}
            >
              <Text style={[styles.sizeBtnText, size === n && styles.sizeBtnTextActive]}>
                {n}×{n}
              </Text>
            </TouchableOpacity>
          ))}
        </View>

        <Text style={styles.sectionLabel}>Matrix A</Text>
        <MatrixGrid grid={gridA} size={size} onChange={(r, c, v) => updateCell('A', r, c, v)} />

        <View style={styles.toggleRow}>
          <TouchableOpacity onPress={() => setNeedsB((s) => !s)} style={styles.toggleBtn}>
            <Text style={styles.toggleBtnText}>
              {needsB ? 'Hide matrix B (unary ops only)' : 'Show matrix B (for +, −, ×)'}
            </Text>
          </TouchableOpacity>
        </View>

        {needsB && (
          <>
            <Text style={styles.sectionLabel}>Matrix B</Text>
            <MatrixGrid grid={gridB} size={size} onChange={(r, c, v) => updateCell('B', r, c, v)} />
          </>
        )}

        <Text style={styles.sectionLabel}>Operations</Text>
        <View style={styles.opsRow}>
          {BINARY_OPS.map((op) => (
            <TouchableOpacity key={op.key} style={styles.opBtn} onPress={() => runBinaryOp(op)}>
              <Text style={styles.opBtnText}>A {op.label} B</Text>
            </TouchableOpacity>
          ))}
        </View>
        <View style={styles.opsRow}>
          {UNARY_OPS.map((op) => (
            <TouchableOpacity key={op.key} style={styles.opBtn} onPress={() => runUnaryOp(op.key)}>
              <Text style={styles.opBtnText}>{op.label}</Text>
            </TouchableOpacity>
          ))}
        </View>

        <Text style={styles.sectionLabel}>Result</Text>
        <View style={styles.resultBox}>
          {error ? (
            <Text style={styles.errorText}>{error}</Text>
          ) : result === null ? (
            <Text style={styles.placeholderText}>Run an operation to see the result here.</Text>
          ) : resultIsScalar ? (
            <Text style={styles.scalarResult}>{formatNumber(result)}</Text>
          ) : (
            <ResultGrid grid={result} />
          )}
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

function formatNumber(n) {
  if (!Number.isFinite(n)) return 'Error';
  const rounded = Math.round(n * 1e8) / 1e8;
  return rounded.toString();
}

function MatrixGrid({ grid, size, onChange }) {
  return (
    <View style={styles.gridWrap}>
      {grid.map((row, r) => (
        <View key={`row-${r}`} style={styles.gridRow}>
          {row.map((cell, c) => (
            <TextInput
              key={`cell-${r}-${c}`}
              style={[styles.cellInput, size === 4 && styles.cellInputSmall]}
              value={cell}
              onChangeText={(v) => onChange(r, c, v)}
              keyboardType="numeric"
              placeholder="0"
              placeholderTextColor={colors.textMuted}
            />
          ))}
        </View>
      ))}
    </View>
  );
}

function ResultGrid({ grid }) {
  return (
    <View style={styles.gridWrap}>
      {grid.map((row, r) => (
        <View key={`rrow-${r}`} style={styles.gridRow}>
          {row.map((val, c) => (
            <View key={`rcell-${r}-${c}`} style={styles.resultCell}>
              <Text style={styles.resultCellText} numberOfLines={1}>{formatNumber(val)}</Text>
            </View>
          ))}
        </View>
      ))}
    </View>
  );
}

const styles = StyleSheet.create({
  safeArea: { flex: 1, backgroundColor: colors.bg },
  container: { padding: spacing.lg, paddingBottom: spacing.xl * 2 },

  sectionLabel: {
    color: colors.textSecondary,
    fontSize: 12,
    fontWeight: '700',
    letterSpacing: 0.5,
    textTransform: 'uppercase',
    marginTop: spacing.lg,
    marginBottom: spacing.sm,
  },

  sizeRow: { flexDirection: 'row', gap: spacing.sm },
  sizeBtn: {
    flex: 1,
    paddingVertical: 10,
    borderRadius: radius.md,
    backgroundColor: colors.panelLight,
    alignItems: 'center',
  },
  sizeBtnActive: { backgroundColor: colors.accentBlue },
  sizeBtnText: { color: colors.textSecondary, fontWeight: '600' },
  sizeBtnTextActive: { color: '#0b0c0f' },

  gridWrap: { backgroundColor: colors.panel, borderRadius: radius.md, padding: spacing.sm, gap: spacing.xs },
  gridRow: { flexDirection: 'row', gap: spacing.xs },
  cellInput: {
    flex: 1,
    height: 48,
    backgroundColor: colors.display,
    borderRadius: radius.sm,
    color: colors.textPrimary,
    textAlign: 'center',
    fontFamily: 'monospace',
    fontSize: 16,
  },
  cellInputSmall: { height: 42, fontSize: 14 },

  toggleRow: { marginTop: spacing.md },
  toggleBtn: { alignSelf: 'flex-start' },
  toggleBtnText: { color: colors.accentBlue, fontSize: 13, fontWeight: '600' },

  opsRow: { flexDirection: 'row', gap: spacing.sm, marginBottom: spacing.sm },
  opBtn: {
    flex: 1,
    paddingVertical: 12,
    backgroundColor: colors.accentOrangeDim,
    borderRadius: radius.md,
    alignItems: 'center',
  },
  opBtnText: { color: colors.accentOrange, fontWeight: '700', fontSize: 14 },

  resultBox: {
    backgroundColor: colors.display,
    borderRadius: radius.md,
    padding: spacing.lg,
    minHeight: 80,
    justifyContent: 'center',
  },
  placeholderText: { color: colors.textMuted, fontSize: 13 },
  errorText: { color: colors.danger, fontSize: 13 },
  scalarResult: { color: colors.textPrimary, fontSize: 28, fontFamily: 'monospace', fontWeight: '600' },

  resultCell: {
    flex: 1,
    height: 44,
    backgroundColor: colors.panelLight,
    borderRadius: radius.sm,
    alignItems: 'center',
    justifyContent: 'center',
  },
  resultCellText: { color: colors.accentGreen, fontFamily: 'monospace', fontSize: 14, fontWeight: '600' },
});
