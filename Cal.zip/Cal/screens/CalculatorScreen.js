/**
 * CalculatorScreen.js
 * -------------------
 * Main scientific calculator. Unlike a simple button-state-machine
 * calculator, this builds a plain text expression string (e.g.
 * "sin(30)+2^3") and runs it through utils/mathUtils.evaluateExpression,
 * a real recursive-descent parser. Buttons just insert text/tokens into
 * the expression -- they don't carry any calculation logic themselves.
 */

import React, { useState, useCallback } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  ScrollView,
  StyleSheet,
  SafeAreaView,
} from 'react-native';
import { evaluateExpression } from '../utils/mathUtils';
import { colors, spacing, radius } from '../theme';

const BASIC_ROWS = [
  ['AC', 'DEL', '(', ')'],
  ['7', '8', '9', '÷'],
  ['4', '5', '6', '×'],
  ['1', '2', '3', '−'],
  ['0', '.', '%', '+'],
];

const SCIENTIFIC_ROWS = [
  ['sin', 'cos', 'tan', 'π'],
  ['asin', 'acos', 'atan', 'e'],
  ['sinh', 'cosh', 'tanh', '^'],
  ['ln', 'log', 'sqrt', '!'],
];

// Map a button's display label to what actually gets inserted into the
// expression string. Functions insert their opening parenthesis too,
// so tapping "sin" gives the user "sin(" with the cursor implicitly
// ready for an argument.
function tokenForLabel(label) {
  switch (label) {
    case '÷': return '/';
    case '×': return '*';
    case '−': return '-';
    case 'π': return 'pi';
    case 'sin': case 'cos': case 'tan':
    case 'asin': case 'acos': case 'atan':
    case 'sinh': case 'cosh': case 'tanh':
    case 'ln': case 'log': case 'sqrt':
      return `${label}(`;
    default:
      return label;
  }
}

export default function CalculatorScreen() {
  const [expression, setExpression] = useState('');
  const [result, setResult] = useState('0');
  const [error, setError] = useState(null);
  const [angleMode, setAngleMode] = useState('deg'); // 'deg' | 'rad'
  const [showScientific, setShowScientific] = useState(false);
  const [history, setHistory] = useState(''); // last evaluated expression, shown faded above

  const tryLivePreview = useCallback((expr) => {
    if (!expr || /[+\-*/^%]$/.test(expr) || /\($/.test(expr)) {
      // Don't attempt to evaluate a clearly-incomplete expression
      // (trailing operator or open paren with nothing after it).
      return;
    }
    try {
      const value = evaluateExpression(expr, angleMode);
      setResult(formatResult(value));
      setError(null);
    } catch (e) {
      // Stay quiet during typing -- only surface errors on explicit "=".
    }
  }, [angleMode]);

  function formatResult(value) {
    if (!Number.isFinite(value)) return 'Error';
    const rounded = Math.round(value * 1e10) / 1e10;
    let str = rounded.toString();
    if (str.length > 14) {
      str = rounded.toPrecision(10).replace(/\.?0+$/, '');
    }
    return str;
  }

  function insertToken(label) {
    setExpression((prev) => {
      const next = prev + tokenForLabel(label);
      tryLivePreview(next);
      return next;
    });
  }

  function handleAC() {
    setExpression('');
    setResult('0');
    setError(null);
    setHistory('');
  }

  function handleDelete() {
    setExpression((prev) => {
      // Remove whole function tokens (e.g. "sin(") in one tap rather than
      // leaving a dangling "sin" with no parenthesis.
      const funcTokens = ['asin(', 'acos(', 'atan(', 'sinh(', 'cosh(', 'tanh(', 'sin(', 'cos(', 'tan(', 'ln(', 'log(', 'sqrt('];
      for (const tok of funcTokens) {
        if (prev.endsWith(tok)) {
          const next = prev.slice(0, -tok.length);
          tryLivePreview(next);
          return next;
        }
      }
      const next = prev.slice(0, -1);
      tryLivePreview(next);
      return next;
    });
  }

  function handleEquals() {
    if (!expression.trim()) return;
    try {
      const value = evaluateExpression(expression, angleMode);
      const formatted = formatResult(value);
      setHistory(`${expression} =`);
      setResult(formatted);
      setExpression(formatted);
      setError(null);
    } catch (e) {
      setError(e.message);
      setResult('Error');
    }
  }

  function handlePress(label) {
    if (label === 'AC') return handleAC();
    if (label === 'DEL') return handleDelete();
    if (label === '=') return handleEquals();
    insertToken(label);
  }

  return (
    <SafeAreaView style={styles.safeArea}>
      <View style={styles.container}>
        {/* Mode toggles */}
        <View style={styles.topRow}>
          <View style={styles.angleToggle}>
            <TouchableOpacity
              style={[styles.angleBtn, angleMode === 'deg' && styles.angleBtnActive]}
              onPress={() => setAngleMode('deg')}
            >
              <Text style={[styles.angleBtnText, angleMode === 'deg' && styles.angleBtnTextActive]}>DEG</Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={[styles.angleBtn, angleMode === 'rad' && styles.angleBtnActive]}
              onPress={() => setAngleMode('rad')}
            >
              <Text style={[styles.angleBtnText, angleMode === 'rad' && styles.angleBtnTextActive]}>RAD</Text>
            </TouchableOpacity>
          </View>

          <TouchableOpacity
            style={styles.sciToggle}
            onPress={() => setShowScientific((s) => !s)}
          >
            <Text style={styles.sciToggleText}>{showScientific ? 'Basic' : 'Scientific'}</Text>
          </TouchableOpacity>
        </View>

        {/* Display: editable text input doubles as the expression field */}
        <View style={styles.display}>
          <Text style={styles.history} numberOfLines={1}>{history || ' '}</Text>
          <TextInput
            style={styles.expressionInput}
            value={expression}
            onChangeText={(text) => {
              setExpression(text);
              tryLivePreview(text);
            }}
            placeholder="0"
            placeholderTextColor={colors.textMuted}
            multiline={false}
            scrollEnabled
            keyboardType="default"
          />
          <ScrollView horizontal showsHorizontalScrollIndicator={false}>
            <Text style={[styles.result, error && styles.resultError]} numberOfLines={1}>
              {error ? 'Error' : result}
            </Text>
          </ScrollView>
          {error ? <Text style={styles.errorDetail} numberOfLines={2}>{error}</Text> : null}
        </View>

        {/* Scientific function panel (collapsible) */}
        {showScientific && (
          <View style={styles.sciPanel}>
            {SCIENTIFIC_ROWS.map((row, i) => (
              <View key={`sci-row-${i}`} style={styles.row}>
                {row.map((label) => (
                  <CalcButton key={label} label={label} onPress={handlePress} variant="fn" />
                ))}
              </View>
            ))}
          </View>
        )}

        {/* Basic keypad */}
        <View style={styles.keypad}>
          {BASIC_ROWS.map((row, i) => (
            <View key={`row-${i}`} style={styles.row}>
              {row.map((label) => (
                <CalcButton
                  key={label}
                  label={label}
                  onPress={handlePress}
                  variant={
                    ['÷', '×', '−', '+'].includes(label) ? 'op' :
                    ['AC', 'DEL', '%'].includes(label) ? 'fn' :
                    ['(', ')'].includes(label) ? 'fn' : 'num'
                  }
                />
              ))}
            </View>
          ))}
          <View style={styles.row}>
            <CalcButton label="=" onPress={handlePress} variant="equals" wide />
          </View>
        </View>
      </View>
    </SafeAreaView>
  );
}

function CalcButton({ label, onPress, variant, wide }) {
  return (
    <TouchableOpacity
      style={[
        styles.key,
        variant === 'op' && styles.keyOp,
        variant === 'fn' && styles.keyFn,
        variant === 'equals' && styles.keyEquals,
        wide && styles.keyWide,
      ]}
      onPress={() => onPress(label)}
      activeOpacity={0.7}
    >
      <Text
        style={[
          styles.keyText,
          variant === 'op' && styles.keyTextOp,
          variant === 'fn' && styles.keyTextFn,
          variant === 'equals' && styles.keyTextEquals,
        ]}
      >
        {label}
      </Text>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  safeArea: { flex: 1, backgroundColor: colors.bg },
  container: { flex: 1, padding: spacing.lg, justifyContent: 'flex-start' },

  topRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: spacing.md,
  },
  angleToggle: {
    flexDirection: 'row',
    backgroundColor: colors.display,
    borderRadius: radius.pill,
    padding: 3,
  },
  angleBtn: { paddingVertical: 6, paddingHorizontal: 14, borderRadius: radius.pill },
  angleBtnActive: { backgroundColor: colors.accentBlue },
  angleBtnText: { color: colors.textMuted, fontSize: 12, fontWeight: '700' },
  angleBtnTextActive: { color: '#0b0c0f' },

  sciToggle: {
    backgroundColor: colors.panelLight,
    paddingVertical: 8,
    paddingHorizontal: 14,
    borderRadius: radius.pill,
  },
  sciToggleText: { color: colors.accentOrange, fontSize: 12, fontWeight: '700' },

  display: {
    backgroundColor: colors.display,
    borderRadius: radius.lg,
    padding: spacing.lg,
    marginBottom: spacing.md,
    minHeight: 130,
    justifyContent: 'flex-end',
  },
  history: { color: colors.textMuted, fontSize: 13, fontFamily: 'monospace', marginBottom: 4 },
  expressionInput: {
    color: colors.textSecondary,
    fontSize: 20,
    fontFamily: 'monospace',
    paddingVertical: 2,
  },
  result: {
    color: colors.textPrimary,
    fontSize: 40,
    fontWeight: '600',
    fontFamily: 'monospace',
    marginTop: 4,
  },
  resultError: { color: colors.danger, fontSize: 22 },
  errorDetail: { color: colors.danger, fontSize: 12, marginTop: 4 },

  sciPanel: { marginBottom: spacing.sm },
  keypad: { flex: 1, justifyContent: 'flex-end' },
  row: { flexDirection: 'row', gap: spacing.sm, marginBottom: spacing.sm },

  key: {
    flex: 1,
    height: 56,
    backgroundColor: colors.key,
    borderRadius: radius.md,
    alignItems: 'center',
    justifyContent: 'center',
  },
  keyOp: { backgroundColor: colors.accentOrangeDim },
  keyFn: { backgroundColor: colors.keyFn, height: 48 },
  keyEquals: { backgroundColor: colors.accentOrange },
  keyWide: { flex: 1 },

  keyText: { color: colors.textPrimary, fontSize: 19, fontWeight: '500' },
  keyTextOp: { color: colors.accentOrange, fontSize: 21, fontWeight: '600' },
  keyTextFn: { color: colors.textPrimary, fontSize: 14, fontWeight: '600' },
  keyTextEquals: { color: '#1a0e05', fontSize: 22, fontWeight: '700' },
});
