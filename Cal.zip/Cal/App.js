/**
 * App.js
 * ------
 * Root component. Sets up bottom-tab navigation between the four screens:
 * Calculator, Matrix, Combinatorics, and Statistics. Dark theme throughout.
 */

import React from 'react';
import { StatusBar } from 'expo-status-bar';
import { NavigationContainer, DarkTheme } from '@react-navigation/native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { Text } from 'react-native';

import CalculatorScreen from './screens/CalculatorScreen';
import MatrixScreen from './screens/MatrixScreen';
import CombinatoricsScreen from './screens/CombinatoricsScreen';
import StatisticsScreen from './screens/StatisticsScreen';
import { colors } from './theme';

const Tab = createBottomTabNavigator();

// Simple text-glyph "icons" so the app has zero external icon-font
// dependencies -- keeps the Expo setup minimal and avoids font-loading
// issues on a tight deadline.
function TabIcon({ glyph, focused }) {
  return (
    <Text style={{ fontSize: 18, color: focused ? colors.accentOrange : colors.textMuted }}>
      {glyph}
    </Text>
  );
}

const navTheme = {
  ...DarkTheme,
  colors: {
    ...DarkTheme.colors,
    background: colors.bg,
    card: colors.panel,
    border: colors.border,
    primary: colors.accentOrange,
    text: colors.textPrimary,
  },
};

export default function App() {
  return (
    <>
      <StatusBar style="light" />
      <NavigationContainer theme={navTheme}>
        <Tab.Navigator
          initialRouteName="Calculator"
          screenOptions={{
            headerStyle: { backgroundColor: colors.panel },
            headerTitleStyle: { color: colors.textPrimary, fontWeight: '600' },
            headerShadowVisible: false,
            tabBarStyle: {
              backgroundColor: colors.panel,
              borderTopColor: colors.border,
              height: 64,
              paddingBottom: 8,
              paddingTop: 6,
            },
            tabBarActiveTintColor: colors.accentOrange,
            tabBarInactiveTintColor: colors.textMuted,
            tabBarLabelStyle: { fontSize: 11, fontWeight: '600' },
          }}
        >
          <Tab.Screen
            name="Calculator"
            component={CalculatorScreen}
            options={{
              title: 'Calculator',
              tabBarIcon: ({ focused }) => <TabIcon glyph="÷" focused={focused} />,
            }}
          />
          <Tab.Screen
            name="Matrix"
            component={MatrixScreen}
            options={{
              title: 'Matrix',
              tabBarIcon: ({ focused }) => <TabIcon glyph="▦" focused={focused} />,
            }}
          />
          <Tab.Screen
            name="Combinatorics"
            component={CombinatoricsScreen}
            options={{
              title: 'Combinatorics',
              tabBarIcon: ({ focused }) => <TabIcon glyph="nCr" focused={focused} />,
            }}
          />
          <Tab.Screen
            name="Statistics"
            component={StatisticsScreen}
            options={{
              title: 'Statistics',
              tabBarIcon: ({ focused }) => <TabIcon glyph="x̄" focused={focused} />,
            }}
          />
        </Tab.Navigator>
      </NavigationContainer>
    </>
  );
}
