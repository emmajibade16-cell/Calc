/**
 * mathUtils.test.js
 * -----------------
 * Plain-Node test suite (no test framework dependency) for utils/mathUtils.js.
 * Run with: node tests/mathUtils.test.js
 *
 * Exits with code 0 if every test passes, 1 if any test fails -- suitable
 * for CI or a pre-commit check.
 */

const path = require('path');
const M = require(path.join(__dirname, '..', 'utils', 'mathUtils.js'));

let passCount = 0;
let failCount = 0;
const failures = [];

function approxEqual(a, b, epsilon = 1e-6) {
  if (Array.isArray(a) && Array.isArray(b)) {
    if (a.length !== b.length) return false;
    return a.every((v, i) => approxEqual(v, b[i], epsilon));
  }
  if (typeof a === 'number' && typeof b === 'number') {
    if (!Number.isFinite(a) && !Number.isFinite(b)) return a === b; // both Infinity etc.
    return Math.abs(a - b) < epsilon;
  }
  return a === b;
}

function test(description, fn) {
  try {
    fn();
    passCount++;
    console.log(`  PASS  ${description}`);
  } catch (err) {
    failCount++;
    failures.push({ description, error: err });
    console.log(`  FAIL  ${description}`);
    console.log(`        ${err.message}`);
  }
}

function assertApprox(actual, expected, msg, epsilon = 1e-6) {
  if (!approxEqual(actual, expected, epsilon)) {
    throw new Error(`${msg || ''} -- expected ${JSON.stringify(expected)}, got ${JSON.stringify(actual)}`);
  }
}

function assertThrows(fn, msg) {
  let threw = false;
  try {
    fn();
  } catch (e) {
    threw = true;
  }
  if (!threw) throw new Error(`${msg || 'Expected function to throw, but it did not'}`);
}

function section(title) {
  console.log(`\n${title}`);
}

// ============================================================
// 1. EXPRESSION PARSER
// ============================================================
section('Expression parser / evaluator');

test('basic addition', () => {
  assertApprox(M.evaluateExpression('2+2'), 4);
});

test('operator precedence: multiplication before addition', () => {
  assertApprox(M.evaluateExpression('1+2*3'), 7);
});

test('parentheses override precedence', () => {
  assertApprox(M.evaluateExpression('(1+2)*3'), 9);
});

test('division', () => {
  assertApprox(M.evaluateExpression('10/4'), 2.5);
});

test('division by zero throws', () => {
  assertThrows(() => M.evaluateExpression('5/0'));
});

test('exponentiation, right-associative', () => {
  assertApprox(M.evaluateExpression('2^3^2'), 512); // 2^(3^2) = 2^9
});

test('unary minus', () => {
  assertApprox(M.evaluateExpression('-5+3'), -2);
});

test('unary minus binds looser than power: -2^2 = -(2^2)', () => {
  assertApprox(M.evaluateExpression('-2^2'), -4);
});

test('factorial postfix operator', () => {
  assertApprox(M.evaluateExpression('5!'), 120);
});

test('factorial combined with addition', () => {
  assertApprox(M.evaluateExpression('3!+4!'), 30);
});

test('sin(30) in degree mode', () => {
  assertApprox(M.evaluateExpression('sin(30)', 'deg'), 0.5);
});

test('cos(0) in degree mode', () => {
  assertApprox(M.evaluateExpression('cos(0)', 'deg'), 1);
});

test('sin(pi/2) in radian mode', () => {
  assertApprox(M.evaluateExpression('sin(pi/2)', 'rad'), 1);
});

test('combined expression: sin(30)+2^3', () => {
  assertApprox(M.evaluateExpression('sin(30)+2^3', 'deg'), 0.5 + 8);
});

test('ln of e equals 1', () => {
  assertApprox(M.evaluateExpression('ln(e)'), 1);
});

test('log base 10 of 100 equals 2', () => {
  assertApprox(M.evaluateExpression('log(100)'), 2);
});

test('sqrt of 16 equals 4', () => {
  assertApprox(M.evaluateExpression('sqrt(16)'), 4);
});

test('implicit multiplication: 2pi', () => {
  assertApprox(M.evaluateExpression('2pi'), 2 * Math.PI);
});

test('implicit multiplication: 3(4+5)', () => {
  assertApprox(M.evaluateExpression('3(4+5)'), 27);
});

test('implicit multiplication: 2sin(90)', () => {
  assertApprox(M.evaluateExpression('2sin(90)', 'deg'), 2);
});

test('asin/acos/atan return degrees in degree mode', () => {
  assertApprox(M.evaluateExpression('asin(1)', 'deg'), 90);
  assertApprox(M.evaluateExpression('acos(0)', 'deg'), 90);
  assertApprox(M.evaluateExpression('atan(1)', 'deg'), 45);
});

test('hyperbolic functions: sinh(0)=0, cosh(0)=1, tanh(0)=0', () => {
  assertApprox(M.evaluateExpression('sinh(0)'), 0);
  assertApprox(M.evaluateExpression('cosh(0)'), 1);
  assertApprox(M.evaluateExpression('tanh(0)'), 0);
});

test('auto-closes unbalanced parentheses', () => {
  assertApprox(M.evaluateExpression('(3+4'), 7);
});

test('empty expression throws', () => {
  assertThrows(() => M.evaluateExpression(''));
});

test('unknown identifier throws', () => {
  assertThrows(() => M.evaluateExpression('foo(1)'));
});

test('modulo operator', () => {
  assertApprox(M.evaluateExpression('10%3'), 1);
});

test('negative factorial throws', () => {
  assertThrows(() => M.evaluateExpression('(-1)!'));
});

// ============================================================
// 2. TRIG / HYPERBOLIC HELPERS
// ============================================================
section('Trig / hyperbolic helper functions');

test('trig.sin(90, deg) = 1', () => {
  assertApprox(M.trig.sin(90, 'deg'), 1);
});

test('trig.cos(180, deg) = -1', () => {
  assertApprox(M.trig.cos(180, 'deg'), -1);
});

test('trig.tan(45, deg) = 1', () => {
  assertApprox(M.trig.tan(45, 'deg'), 1);
});

test('trig functions agree in rad mode with Math built-ins', () => {
  assertApprox(M.trig.sin(Math.PI / 2, 'rad'), Math.sin(Math.PI / 2));
});

test('hyperbolic.cosh(1) matches Math.cosh(1)', () => {
  assertApprox(M.hyperbolic.cosh(1), Math.cosh(1));
});

// ============================================================
// 3. COMBINATORICS
// ============================================================
section('Combinatorics: factorial, nPr, nCr');

test('factorial(0) = 1', () => {
  assertApprox(M.factorial(0), 1);
});

test('factorial(5) = 120', () => {
  assertApprox(M.factorial(5), 120);
});

test('factorial(10) = 3628800', () => {
  assertApprox(M.factorial(10), 3628800);
});

test('factorial of negative number throws', () => {
  assertThrows(() => M.factorial(-3));
});

test('factorial of non-integer throws', () => {
  assertThrows(() => M.factorial(2.5));
});

test('nPr(5,2) = 20', () => {
  assertApprox(M.nPr(5, 2), 20);
});

test('nPr(10,3) = 720', () => {
  assertApprox(M.nPr(10, 3), 720);
});

test('nPr(n,0) = 1 for any n', () => {
  assertApprox(M.nPr(7, 0), 1);
});

test('nPr(n,n) = n!', () => {
  assertApprox(M.nPr(6, 6), M.factorial(6));
});

test('nCr(5,2) = 10', () => {
  assertApprox(M.nCr(5, 2), 10);
});

test('nCr(52,5) = 2598960 (poker hands)', () => {
  assertApprox(M.nCr(52, 5), 2598960);
});

test('nCr(n,0) = 1', () => {
  assertApprox(M.nCr(9, 0), 1);
});

test('nCr(n,n) = 1', () => {
  assertApprox(M.nCr(9, 9), 1);
});

test('nCr is symmetric: nCr(10,3) = nCr(10,7)', () => {
  assertApprox(M.nCr(10, 3), M.nCr(10, 7));
});

test('nPr with r > n throws', () => {
  assertThrows(() => M.nPr(3, 5));
});

test('nCr with r > n throws', () => {
  assertThrows(() => M.nCr(3, 5));
});

// ============================================================
// 4. MATRIX OPERATIONS
// ============================================================
section('Matrix operations (2x2, 3x3, 4x4)');

test('2x2 matrix addition', () => {
  const a = [[1, 2], [3, 4]];
  const b = [[5, 6], [7, 8]];
  assertApprox(M.matrixAdd(a, b), [[6, 8], [10, 12]]);
});

test('2x2 matrix subtraction', () => {
  const a = [[5, 6], [7, 8]];
  const b = [[1, 2], [3, 4]];
  assertApprox(M.matrixSubtract(a, b), [[4, 4], [4, 4]]);
});

test('2x2 matrix multiplication', () => {
  const a = [[1, 2], [3, 4]];
  const b = [[5, 6], [7, 8]];
  // [1*5+2*7, 1*6+2*8; 3*5+4*7, 3*6+4*8] = [19,22; 43,50]
  assertApprox(M.matrixMultiply(a, b), [[19, 22], [43, 50]]);
});

test('mismatched dimensions for add throws', () => {
  assertThrows(() => M.matrixAdd([[1, 2]], [[1, 2, 3]]));
});

test('incompatible dimensions for multiply throws', () => {
  assertThrows(() => M.matrixMultiply([[1, 2]], [[1, 2]]));
});

test('2x2 determinant', () => {
  assertApprox(M.matrixDeterminant([[1, 2], [3, 4]]), 1 * 4 - 2 * 3);
});

test('3x3 determinant (known example)', () => {
  const m = [
    [6, 1, 1],
    [4, -2, 5],
    [2, 8, 7],
  ];
  // Known determinant of this matrix = -306
  assertApprox(M.matrixDeterminant(m), -306);
});

test('4x4 determinant of identity matrix = 1', () => {
  const identity4 = [
    [1, 0, 0, 0],
    [0, 1, 0, 0],
    [0, 0, 1, 0],
    [0, 0, 0, 1],
  ];
  assertApprox(M.matrixDeterminant(identity4), 1);
});

test('determinant of singular matrix is 0', () => {
  const singular = [[1, 2], [2, 4]]; // row2 = 2*row1
  assertApprox(M.matrixDeterminant(singular), 0);
});

test('2x2 transpose', () => {
  assertApprox(M.matrixTranspose([[1, 2], [3, 4]]), [[1, 3], [2, 4]]);
});

test('non-square transpose (2x3 -> 3x2)', () => {
  assertApprox(M.matrixTranspose([[1, 2, 3], [4, 5, 6]]), [[1, 4], [2, 5], [3, 6]]);
});

test('2x2 inverse: A * inverse(A) = identity', () => {
  const a = [[4, 7], [2, 6]];
  const inv = M.matrixInverse(a);
  const product = M.matrixMultiply(a, inv);
  assertApprox(product, [[1, 0], [0, 1]], 'A * A^-1 should be identity', 1e-9);
});

test('3x3 inverse: A * inverse(A) = identity', () => {
  const a = [
    [1, 2, 3],
    [0, 1, 4],
    [5, 6, 0],
  ];
  const inv = M.matrixInverse(a);
  const product = M.matrixMultiply(a, inv);
  const identity3 = [[1, 0, 0], [0, 1, 0], [0, 0, 1]];
  assertApprox(product, identity3, 'A * A^-1 should be identity', 1e-8);
});

test('4x4 inverse: A * inverse(A) = identity', () => {
  const a = [
    [4, 0, 0, 0],
    [0, 3, 0, 0],
    [0, 0, 2, 0],
    [0, 0, 0, 5],
  ];
  const inv = M.matrixInverse(a);
  const product = M.matrixMultiply(a, inv);
  const identity4 = [
    [1, 0, 0, 0],
    [0, 1, 0, 0],
    [0, 0, 1, 0],
    [0, 0, 0, 1],
  ];
  assertApprox(product, identity4, 'A * A^-1 should be identity', 1e-8);
});

test('inverse of singular matrix throws', () => {
  const singular = [[1, 2], [2, 4]];
  assertThrows(() => M.matrixInverse(singular));
});

test('inverse of non-square matrix throws', () => {
  assertThrows(() => M.matrixInverse([[1, 2, 3], [4, 5, 6]]));
});

// ============================================================
// 5. STATISTICS
// ============================================================
section('Statistics: mean, median, mode, variance, stddev, range, min, max');

const dataset = [4, 8, 6, 5, 3, 2, 8, 9, 2, 5];

test('mean of [4,8,6,5,3,2,8,9,2,5]', () => {
  // sum = 52, count = 10
  assertApprox(M.mean(dataset), 5.2);
});

test('median of even-length dataset', () => {
  // sorted: 2,2,3,4,5,5,6,8,8,9 -> mid two are 5,5 -> 5
  assertApprox(M.median(dataset), 5);
});

test('median of odd-length dataset', () => {
  assertApprox(M.median([3, 1, 2]), 2);
});

test('mode finds the most frequent value(s)', () => {
  // 2 appears twice, 5 appears twice, 8 appears twice -- all tied at freq 2
  const result = M.mode(dataset);
  assertApprox(result.slice().sort((a, b) => a - b), [2, 5, 8]);
});

test('mode of dataset with single clear mode', () => {
  assertApprox(M.mode([1, 2, 2, 2, 3]), [2]);
});

test('sample variance of [2,4,4,4,5,5,7,9]', () => {
  // known textbook example: population variance = 4, sample variance = 32/7
  assertApprox(M.variance([2, 4, 4, 4, 5, 5, 7, 9], { population: true }), 4);
});

test('sample standard deviation of [2,4,4,4,5,5,7,9] (population) = 2', () => {
  assertApprox(M.standardDeviation([2, 4, 4, 4, 5, 5, 7, 9], { population: true }), 2);
});

test('variance requires at least 2 points for sample mode', () => {
  assertThrows(() => M.variance([5]));
});

test('range of dataset', () => {
  assertApprox(M.range(dataset), 9 - 2); // max 9, min 2
});

test('min of dataset', () => {
  assertApprox(M.min(dataset), 2);
});

test('max of dataset', () => {
  assertApprox(M.max(dataset), 9);
});

test('summarizeStatistics bundles all stats correctly', () => {
  const summary = M.summarizeStatistics(dataset);
  assertApprox(summary.mean, 5.2);
  assertApprox(summary.median, 5);
  assertApprox(summary.min, 2);
  assertApprox(summary.max, 9);
  assertApprox(summary.range, 7);
  assertApprox(summary.count, 10);
});

test('statistics functions throw on empty array', () => {
  assertThrows(() => M.mean([]));
  assertThrows(() => M.median([]));
});

test('statistics functions throw on non-numeric entries', () => {
  assertThrows(() => M.mean([1, 2, 'three']));
});

// ============================================================
// SUMMARY
// ============================================================
console.log('\n' + '='.repeat(50));
console.log(`TOTAL: ${passCount + failCount}  PASS: ${passCount}  FAIL: ${failCount}`);
console.log('='.repeat(50));

if (failCount > 0) {
  console.log('\nFailed tests:');
  failures.forEach((f) => console.log(`  - ${f.description}: ${f.error.message}`));
  process.exit(1);
} else {
  console.log('\nAll tests passed.');
  process.exit(0);
}
