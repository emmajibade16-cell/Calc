# Cal — scientific calculator (React Native / Expo)

A scientific calculator app built for SEN 104 & 214. Four screens, dark theme,
all math logic separated from the UI and unit tested.

## Features

**Required**
- Addition, subtraction, multiplication, division

**Bonus (all implemented)**
- Trigonometric functions: `sin`, `cos`, `tan`, `asin`, `acos`, `atan`, with a DEG/RAD toggle
- Hyperbolic functions: `sinh`, `cosh`, `tanh`
- Matrix operations for 2×2, 3×3, and 4×4 matrices: add, subtract, multiply, determinant, inverse, transpose
- Permutations (`nPr`), combinations (`nCr`), and factorial
- Statistics: mean, median, mode, variance, standard deviation, range, min, max

The main calculator uses a real **typed-expression parser** — you type something
like `sin(30)+2^3` and it's tokenized and evaluated with a recursive-descent
parser (proper operator precedence, implicit multiplication, unary minus,
functions, parentheses), not a button-by-button state machine.

## Project structure

```
Cal/
├── App.js                      # tab navigation root
├── theme.js                    # shared dark-theme colors/spacing tokens
├── app.json                    # Expo config
├── eas.json                    # EAS build profiles (for APK builds)
├── babel.config.js
├── package.json
├── utils/
│   └── mathUtils.js             # ALL math logic, as pure functions, no UI code
├── screens/
│   ├── CalculatorScreen.js      # expression parser-based calculator UI
│   ├── MatrixScreen.js          # matrix operations UI
│   ├── CombinatoricsScreen.js   # factorial / nPr / nCr UI
│   └── StatisticsScreen.js      # dataset statistics UI
└── tests/
    └── mathUtils.test.js        # plain-Node test suite for utils/mathUtils.js
```

`utils/mathUtils.js` has zero React/React Native imports — it's pure
JavaScript functions, which is what makes it possible to test with plain
`node`, no emulator or test framework required.

## Setup

You'll need [Node.js](https://nodejs.org) (18 or later) installed.

```bash
# 1. Install dependencies
npm install

# 2. Start the Expo dev server
npx expo start
```

This opens a QR code in your terminal/browser. From there:
- **On your phone**: install the **Expo Go** app (Android/iOS), then scan the QR code.
- **Android emulator**: press `a` in the terminal once the dev server is running (requires Android Studio with an emulator set up).
- **iOS simulator** (Mac only): press `i`.
- **Web** (quick preview, not the real mobile UI): press `w`.

If you hit a "Unable to resolve module" type error after `npm install`, try
clearing the cache: `npx expo start -c`.

> **Note on app icons**: this repo ships without custom icon/splash image
> files, so Expo falls back to its own default icon. If you want a custom
> app icon for the build, add `icon.png` (1024×1024) and reference it in
> `app.json` under `expo.icon` — not required for the app to run or build.

## Running the math tests

The math logic has its own test suite, separate from the app, so you can
verify it without spinning up a simulator:

```bash
npm test
```

or directly:

```bash
node tests/mathUtils.test.js
```

This runs 78 test cases across the expression parser, trig/hyperbolic
functions, factorial/nPr/nCr, all three matrix sizes (including verifying
`A × A⁻¹ = identity` for 2×2, 3×3, and 4×4), and the statistics functions.
It exits with code 0 if everything passes, 1 if anything fails — so it's
also CI-friendly if you want to add a GitHub Action later.

## Building an APK (for submission / sideloading)

The app is built with Expo, so the easiest path to a real `.apk` you can
install on an Android phone is **EAS Build**, Expo's cloud build service
(free tier is enough for this).

```bash
# 1. Install the EAS CLI globally (one-time)
npm install -g eas-cli

# 2. Log in (creates a free Expo account if you don't have one)
eas login

# 3. Configure the project for EAS (one-time; links it to an Expo project)
eas build:configure

# 4. Build an installable APK
eas build --platform android --profile preview
```

This uploads your project to Expo's build servers and gives you a link to
download the `.apk` once it finishes (usually a few minutes). The `preview`
profile in `eas.json` is set to produce a plain `.apk` (not an `.aab`),
which is what you want for direct installation/sideloading rather than a
Play Store submission.

If you don't want to make an Expo account, you can also run a local Android
build with `npx expo prebuild` + Android Studio/Gradle, but EAS is faster
to set up under a deadline.

## How the expression parser works (for the "real understanding" requirement)

`utils/mathUtils.js` implements a small recursive-descent parser:

1. **Tokenizer** (`tokenize`) — turns the raw string into tokens: numbers,
   identifiers (function names like `sin` or constants like `pi`), operators,
   and parentheses.
2. **Parser/evaluator** (`createParser` → `evaluateExpression`) — a grammar
   with explicit precedence levels, low to high:
   ```
   expression := term (('+' | '-') term)*
   term       := unary (('*' | '/' | '%') unary)*
   unary      := ('-' | '+')? power
   power      := postfix ('^' unary)?      (right-associative)
   postfix    := primary ('!')*
   primary    := NUMBER | CONST | FUNC '(' args ')' | '(' expression ')'
   ```
   Implicit multiplication (`2pi`, `3(4+5)`, `2sin(90)`) is handled inside
   `term()` by checking whether the next token could start a new primary
   expression with no operator between.

This means `sin(30)+2^3` is parsed as `sin(30) + (2^3)` correctly (functions
and exponents bind tighter than addition), and DEG/RAD mode is threaded
through the trig functions at evaluation time.

## Notes on matrix math

- **Determinant**: cofactor expansion (recursive). Fine for the 2×2–4×4
  sizes this app supports.
- **Inverse**: Gauss-Jordan elimination with partial pivoting, which works
  for any N×N (not just the simple 2×2 formula) and throws a clear error
  if the matrix is singular.
- All matrix functions validate dimensions before computing and throw
  descriptive errors (e.g. mismatched sizes for addition, non-square for
  inverse/determinant) rather than silently returning `NaN`.

## Known limitations / things to extend if you have time

- The calculator's live-preview evaluation silently ignores parse errors
  while you're still typing (e.g. `sin(`), and only surfaces an error
  message once you press `=`. This is intentional UX, not a bug, but worth
  knowing about if you're checking error-handling behavior.
- `mode()` returns *all* tied values when there's a multi-way tie (e.g. for
  `[1,1,2,2,3]` it returns `[1,2]`), which matches the standard statistical
  definition of mode but is worth mentioning if your course uses a stricter
  "no mode if tied" convention.
- Statistics screen uses **sample** variance/standard deviation (divides by
  `n−1`) by default. `mathUtils.variance(data, { population: true })` is
  available if your assignment expects population variance instead — easy
  one-line change in `StatisticsScreen.js` if needed.
